/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package dev.vxs.frostsoulx.utils

import androidx.datastore.preferences.core.edit
import io.ktor.client.HttpClient
import io.ktor.client.request.get
import io.ktor.client.request.headers
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpStatusCode
import kotlinx.coroutines.CancellationException
import dev.vxs.frostsoulx.App
import dev.vxs.frostsoulx.BuildConfig
import dev.vxs.frostsoulx.constants.CanaryReleasesEtagKey
import dev.vxs.frostsoulx.constants.CanaryReleasesFingerprintKey
import dev.vxs.frostsoulx.constants.CanaryReleasesJsonKey
import dev.vxs.frostsoulx.constants.CanaryReleasesLastCheckedAtKey
import dev.vxs.frostsoulx.constants.GitHubReleasesEtagKey
import dev.vxs.frostsoulx.constants.GitHubReleasesFingerprintKey
import dev.vxs.frostsoulx.constants.GitHubReleasesJsonKey
import dev.vxs.frostsoulx.constants.GitHubReleasesLastCheckedAtKey
import org.json.JSONArray
import org.json.JSONObject

data class GitCommit(
    val sha: String,
    val message: String,
    val author: String,
    val date: String,
    val url: String,
    val authorAvatarUrl: String? = null,
)

data class ReleaseInfo(
    val tagName: String,
    val name: String,
    val body: String?,
    val publishedAt: String,
    val htmlUrl: String,
    val downloadUrl: String? = null,
)

private data class ReleasesNetworkResult(
    val status: HttpStatusCode,
    val body: String?,
    val etag: String?,
)

object Updater {
    private val client = HttpClient()
    private const val ReleaseCacheCheckIntervalMs: Long = 6 * 60 * 60 * 1000L
    private const val StableReleaseBaseUrl = "https://github.com/sakuraDev31/frostsoulx/releases"
    private const val CanaryReleaseBaseUrl =
        "https://github.com/sakuraDev31/frostsoulx/releases"
    private const val CanaryWorkflowRunsUrl =
        "https://api.github.com/repos/sakuraDev31/frostsoulx/actions/workflows/build.yml/runs" +
            "?branch=dev&status=success&per_page=1&exclude_pull_requests=true"
    var lastCheckTime = -1L
        private set
    private var latestReleaseTag: String? = null
    private var latestCanaryReleaseTag: String? = null
    private var latestReleaseDownloadUrl: String? = null
    private var latestCanaryDownloadUrl: String? = null

    private val isUpdaterDistribution: Boolean
        get() =
            BuildConfig.UPDATER_AVAILABLE &&
                when (BuildConfig.DISTRIBUTION) {
                    "gms", "foss" -> true
                    else -> false
                }

    private val canDownloadUpdatesDirectly: Boolean
        get() = BuildConfig.DISTRIBUTION == "gms"

    private val releaseArtifactPrefix: String
        get() =
            when (BuildConfig.DISTRIBUTION) {
                "gms" -> "gms-"
                "foss" -> "foss-"
                else -> ""
            }

    private fun stableReleaseArtifactName(): String =
        "app-$releaseArtifactPrefix${BuildConfig.DEVICE}-${BuildConfig.ARCHITECTURE}-release.apk"

    private fun canaryReleaseArtifactName(): String =
        "app-$releaseArtifactPrefix${BuildConfig.DEVICE}-${BuildConfig.ARCHITECTURE}-nightly.apk"

    private fun workflowArtifactName(): String =
        "app-$releaseArtifactPrefix${BuildConfig.DEVICE}-${BuildConfig.ARCHITECTURE}-release"

    private fun workflowArtifactDownloadUrl(): String {
        val artifactUrl =
            "https://nightly.link/sakuraDev31/frostsoulx/workflows/build/dev/${workflowArtifactName()}"
        return if (canDownloadUpdatesDirectly) "$artifactUrl.zip" else artifactUrl
    }

    private data class SemVer(
        val major: Int,
        val minor: Int,
        val patch: Int,
        val preRelease: List<PreReleaseIdentifier>,
    ) : Comparable<SemVer> {
        override fun compareTo(other: SemVer): Int {
            val majorCompare = major.compareTo(other.major)
            if (majorCompare != 0) return majorCompare
            val minorCompare = minor.compareTo(other.minor)
            if (minorCompare != 0) return minorCompare
            val patchCompare = patch.compareTo(other.patch)
            if (patchCompare != 0) return patchCompare

            val thisIsStable = preRelease.isEmpty()
            val otherIsStable = other.preRelease.isEmpty()
            if (thisIsStable && !otherIsStable) return 1
            if (!thisIsStable && otherIsStable) return -1

            val maxIndex = minOf(preRelease.size, other.preRelease.size)
            for (i in 0 until maxIndex) {
                val c = preRelease[i].compareTo(other.preRelease[i])
                if (c != 0) return c
            }
            return preRelease.size.compareTo(other.preRelease.size)
        }

        fun normalizedName(): String =
            if (preRelease.isEmpty()) {
                "$major.$minor.$patch"
            } else {
                "$major.$minor.$patch-" + preRelease.joinToString(".") { it.raw }
            }
    }

    private sealed interface PreReleaseIdentifier : Comparable<PreReleaseIdentifier> {
        val raw: String
    }

    private data class NumericIdentifier(
        override val raw: String,
        val value: Long,
    ) : PreReleaseIdentifier {
        override fun compareTo(other: PreReleaseIdentifier): Int =
            when (other) {
                is NumericIdentifier -> value.compareTo(other.value)
                is AlphaIdentifier -> -1
            }
    }

    private data class AlphaIdentifier(
        override val raw: String,
    ) : PreReleaseIdentifier {
        override fun compareTo(other: PreReleaseIdentifier): Int =
            when (other) {
                is NumericIdentifier -> 1
                is AlphaIdentifier -> raw.compareTo(other.raw)
            }
    }

    private val semVerRegex =
        Regex("""(?i)\bv?(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?\b""")
    private val canaryTagRegex = Regex("""N\d{8}""")

    private fun parseSemVerOrNull(text: String): SemVer? {
        val match = semVerRegex.find(text) ?: return null
        val major = match.groupValues.getOrNull(1)?.toIntOrNull() ?: return null
        val minor = match.groupValues.getOrNull(2)?.toIntOrNull() ?: return null
        val patch = match.groupValues.getOrNull(3)?.toIntOrNull() ?: return null
        val preReleaseText = match.groupValues.getOrNull(4)?.takeIf { it.isNotBlank() }
        val preRelease =
            preReleaseText
                ?.split('.')
                ?.filter { it.isNotBlank() }
                ?.map { identifier ->
                    if (identifier.all { it.isDigit() }) {
                        NumericIdentifier(raw = identifier, value = identifier.toLong())
                    } else {
                        AlphaIdentifier(raw = identifier)
                    }
                }
                ?: emptyList()
        return SemVer(
            major = major,
            minor = minor,
            patch = patch,
            preRelease = preRelease,
        )
    }

    private fun parseReleaseSemVerOrNull(release: ReleaseInfo): SemVer? =
        parseSemVerOrNull(release.tagName) ?: parseSemVerOrNull(release.name)

    internal fun isSameVersion(
        a: String,
        b: String,
    ): Boolean {
        val aSemVer = parseSemVerOrNull(a)
        val bSemVer = parseSemVerOrNull(b)
        return if (aSemVer != null && bSemVer != null) {
            aSemVer.major == bSemVer.major &&
                aSemVer.minor == bSemVer.minor &&
                aSemVer.patch == bSemVer.patch &&
                aSemVer.preRelease == bSemVer.preRelease
        } else {
            a.trim() == b.trim()
        }
    }

    internal fun isUpdateAvailable(
        latestVersion: String,
        currentVersion: String,
    ): Boolean {
        val latestSemVer = parseSemVerOrNull(latestVersion)
        val currentSemVer = parseSemVerOrNull(currentVersion)
        return if (latestSemVer != null && currentSemVer != null) {
            latestSemVer > currentSemVer
        } else {
            !isSameVersion(latestVersion, currentVersion)
        }
    }

    internal fun findLatestRelease(releases: List<ReleaseInfo>): ReleaseInfo? {
        if (releases.isEmpty()) return null
        val parsed =
            releases.mapNotNull { release ->
                parseReleaseSemVerOrNull(release)?.let { version -> version to release }
            }

        if (parsed.isEmpty()) return releases.firstOrNull()

        val stable = parsed.filter { it.first.preRelease.isEmpty() }
        val candidates = stable.ifEmpty { parsed }
        return candidates.maxWithOrNull(compareBy({ it.first }, { it.second.publishedAt }))?.second
    }

    internal fun findLatestCanaryRelease(releases: List<ReleaseInfo>): ReleaseInfo? {
        if (releases.isEmpty()) return null
        return releases.maxByOrNull { release ->
            val dateTag = release.tagName.removePrefix("N").takeWhile { it.isDigit() }
            dateTag.toLongOrNull() ?: 0L
        }
    }

    private fun preferredReleaseVersionNameOrNull(release: ReleaseInfo): String? =
        parseReleaseSemVerOrNull(release)?.normalizedName()

    internal fun getReleaseVersionName(release: ReleaseInfo): String =
        preferredReleaseVersionNameOrNull(release) ?: release.name.ifBlank { release.tagName }

    private fun parseReleasesJson(
        json: String,
        expectedArtifactName: String,
    ): List<ReleaseInfo> {
        val jsonArray = JSONArray(json)
        val releases = ArrayList<ReleaseInfo>(jsonArray.length())
        for (i in 0 until jsonArray.length()) {
            val item = jsonArray.getJSONObject(i)
            val assets = item.optJSONArray("assets")
            val assetDownloadUrl =
                assets?.let { releaseAssets ->
                    (0 until releaseAssets.length())
                        .asSequence()
                        .mapNotNull(releaseAssets::optJSONObject)
                        .firstOrNull { asset -> asset.optString("name") == expectedArtifactName }
                        ?.optString("browser_download_url")
                        ?.takeIf { it.isNotBlank() }
                }
            releases.add(
                ReleaseInfo(
                    tagName = item.optString("tag_name", ""),
                    name = item.optString("name", ""),
                    body = if (item.isNull("body")) null else item.optString("body"),
                    publishedAt = item.optString("published_at", ""),
                    htmlUrl = item.optString("html_url", ""),
                    downloadUrl =
                        if (item.isNull("download_url")) {
                            null
                        } else {
                            item.optString("download_url").takeIf { it.isNotBlank() }
                        }
                            ?: assetDownloadUrl,
                ),
            )
        }
        return releases
    }

    private fun encodeReleasesJson(releases: List<ReleaseInfo>): String =
        JSONArray().apply {
            releases.forEach { release ->
                put(
                    JSONObject().apply {
                        put("tag_name", release.tagName)
                        put("name", release.name)
                        put("body", release.body ?: JSONObject.NULL)
                        put("published_at", release.publishedAt)
                        put("html_url", release.htmlUrl)
                        put("download_url", release.downloadUrl ?: JSONObject.NULL)
                    },
                )
            }
        }.toString()

    private fun getTopReleaseFingerprint(releases: List<ReleaseInfo>): String {
        val latest = findLatestRelease(releases) ?: return ""
        return listOf(
            latest.tagName,
            latest.name,
            latest.publishedAt,
            latest.body.orEmpty(),
            latest.htmlUrl,
        ).joinToString("||")
    }

    private suspend fun fetchReleasesNetwork(
        perPage: Int,
        cachedEtag: String?,
    ): ReleasesNetworkResult {
        val response: HttpResponse =
            client.get("https://api.github.com/repos/sakuraDev31/frostsoulx/releases?per_page=$perPage") {
                headers {
                    append("Accept", "application/vnd.github+json")
                    append("User-Agent", "ArchiveTune")
                    if (!cachedEtag.isNullOrBlank()) {
                        append("If-None-Match", cachedEtag)
                    }
                }
            }
        val etag = response.headers["ETag"]
        return when (response.status) {
            HttpStatusCode.NotModified -> {
                ReleasesNetworkResult(
                    status = response.status,
                    body = null,
                    etag = cachedEtag ?: etag,
                )
            }

            else -> {
                ReleasesNetworkResult(
                    status = response.status,
                    body = response.bodyAsText(),
                    etag = etag,
                )
            }
        }
    }

    suspend fun getCachedReleases(): List<ReleaseInfo> {
        if (!isUpdaterDistribution) {
            return emptyList()
        }

        val cachedJson = App.instance.dataStore.getAsync(GitHubReleasesJsonKey)
        return cachedJson
            ?.takeIf { it.isNotBlank() }
            ?.let { runCatching { parseReleasesJson(it, stableReleaseArtifactName()) }.getOrNull() }
            ?: emptyList()
    }

    suspend fun getLatestVersionName(): Result<String> = getLatestReleaseInfo().map(::getReleaseVersionName)

    suspend fun getLatestReleaseNotes(): Result<String?> = getLatestReleaseInfo().map { it.body }

    suspend fun getLatestReleaseInfo(forceRefresh: Boolean = false): Result<ReleaseInfo> =
        runCatchingCancellable {
            if (!isUpdaterDistribution) {
                throw IllegalStateException("Updater is not available for this distribution")
            }

            val releases = getAllReleases(forceRefresh = forceRefresh).getOrThrow()
            val latest =
                findLatestRelease(releases)
                    ?: throw IllegalStateException("No releases found")
            lastCheckTime = System.currentTimeMillis()
            latestReleaseTag = latest.tagName
            latestReleaseDownloadUrl = latest.downloadUrl
            latest
        }

    suspend fun getCommitHistory(
        count: Int = 20,
        branch: String = "dev",
    ): Result<List<GitCommit>> =
        runCatchingCancellable {
            if (!isUpdaterDistribution) {
                return@runCatchingCancellable emptyList()
            }

            val response =
                client
                    .get("https://api.github.com/repos/sakuraDev31/frostsoulx/commits?sha=$branch&per_page=$count")
                    .bodyAsText()
            val jsonArray = JSONArray(response)
            val commits = mutableListOf<GitCommit>()
            for (i in 0 until jsonArray.length()) {
                val commitObj = jsonArray.getJSONObject(i)
                val commit = commitObj.getJSONObject("commit")
                val authorObj = commit.optJSONObject("author")
                val githubAuthorObj = commitObj.optJSONObject("author")
                commits.add(
                    GitCommit(
                        sha = commitObj.optString("sha", "").take(7),
                        message = commit.optString("message", "").lines().firstOrNull() ?: "",
                        author = authorObj?.optString("name", "Unknown") ?: "Unknown",
                        date = authorObj?.optString("date", "") ?: "",
                        url = commitObj.optString("html_url", ""),
                        authorAvatarUrl = githubAuthorObj?.optString("avatar_url")?.takeIf { it.isNotBlank() },
                    ),
                )
            }
            commits
        }

    fun getLatestDownloadUrl(): String {
        if (!isUpdaterDistribution) {
            return ""
        }

        if (!canDownloadUpdatesDirectly) {
            return "$StableReleaseBaseUrl/latest"
        }

        val artifactName = stableReleaseArtifactName()
        latestReleaseDownloadUrl?.let { return it }
        val tag = latestReleaseTag
        if (tag != null) {
            return "$StableReleaseBaseUrl/download/$tag/$artifactName"
        }
        return "$StableReleaseBaseUrl/latest/download/$artifactName"
    }

    suspend fun getLatestCanaryVersionName(): Result<String> =
        getLatestCanaryReleaseInfo().map(::getReleaseVersionName)

    suspend fun getLatestCanaryReleaseNotes(): Result<String?> = getLatestCanaryReleaseInfo().map { it.body }

    suspend fun getLatestCanaryReleaseInfo(forceRefresh: Boolean = false): Result<ReleaseInfo> =
        runCatchingCancellable {
            if (!isUpdaterDistribution) {
                throw IllegalStateException("Updater is not available for this distribution")
            }

            val releases = getAllCanaryReleases(forceRefresh = forceRefresh).getOrThrow()
            val latest =
                findLatestCanaryRelease(releases)
                    ?: throw IllegalStateException("No Canary releases found")
            lastCheckTime = System.currentTimeMillis()
            latestCanaryReleaseTag = latest.tagName
            latestCanaryDownloadUrl = latest.downloadUrl
            latest
        }

    suspend fun getCachedCanaryReleases(): List<ReleaseInfo> {
        if (!isUpdaterDistribution) {
            return emptyList()
        }

        val cachedJson = App.instance.dataStore.getAsync(CanaryReleasesJsonKey)
        return cachedJson
            ?.takeIf { it.isNotBlank() }
            ?.let { runCatching { parseReleasesJson(it, canaryReleaseArtifactName()) }.getOrNull() }
            ?: emptyList()
    }

    suspend fun getAllCanaryReleases(
        perPage: Int = 10,
        forceRefresh: Boolean = false,
    ): Result<List<ReleaseInfo>> {
        if (!isUpdaterDistribution) {
            return Result.success(emptyList())
        }

        return runCatchingCancellable {
            val now = System.currentTimeMillis()
            val cachedJson = App.instance.dataStore.getAsync(CanaryReleasesJsonKey)
            val cachedEtag = App.instance.dataStore.getAsync(CanaryReleasesEtagKey)
            val lastCheckedAt = App.instance.dataStore.getAsync(CanaryReleasesLastCheckedAtKey, 0L)
            val cachedFingerprint = App.instance.dataStore.getAsync(CanaryReleasesFingerprintKey)

            val cachedReleases =
                cachedJson
                    ?.takeIf { it.isNotBlank() }
                    ?.let { runCatching { parseReleasesJson(it, canaryReleaseArtifactName()) }.getOrNull() }

            val shouldCheckNetwork =
                forceRefresh || cachedJson.isNullOrBlank() || (now - lastCheckedAt) >= ReleaseCacheCheckIntervalMs

            if (!shouldCheckNetwork) {
                return@runCatchingCancellable cachedReleases ?: emptyList()
            }

            val networkResult =
                try {
                    fetchCanaryReleasesNetwork(
                        perPage = perPage,
                        cachedEtag = cachedEtag,
                    )
                } catch (error: CancellationException) {
                    throw error
                } catch (_: Exception) {
                    null
                }

            when {
                networkResult?.status == HttpStatusCode.NotModified && cachedReleases != null -> {
                    App.instance.dataStore.edit { settings ->
                        settings[CanaryReleasesLastCheckedAtKey] = now
                        networkResult.etag?.let { settings[CanaryReleasesEtagKey] = it }
                    }
                    return@runCatchingCancellable cachedReleases
                }

                networkResult != null &&
                    networkResult.status.value in 200..299 &&
                    !networkResult.body.isNullOrBlank() -> {
                    val networkBody = networkResult.body
                    val releases = parseReleasesJson(networkBody, canaryReleaseArtifactName())
                    if (releases.isNotEmpty()) {
                        val newFingerprint = getCanaryTopReleaseFingerprint(releases)
                        val hasPayloadChanged = cachedJson != networkBody
                        val hasTopReleaseChanged = cachedFingerprint != newFingerprint

                        App.instance.dataStore.edit { settings ->
                            settings[CanaryReleasesLastCheckedAtKey] = now
                            networkResult.etag?.let { settings[CanaryReleasesEtagKey] = it }
                            if (hasPayloadChanged || hasTopReleaseChanged || cachedJson.isNullOrBlank()) {
                                settings[CanaryReleasesJsonKey] = networkBody
                                settings[CanaryReleasesFingerprintKey] = newFingerprint
                            }
                        }
                        return@runCatchingCancellable releases
                    }
                }
            }

            val releasePageFallback =
                try {
                    fetchLatestCanaryReleasePage()
                } catch (error: CancellationException) {
                    throw error
                } catch (_: Exception) {
                    null
                }
            val workflowFallback =
                if (releasePageFallback == null) {
                    try {
                        fetchLatestWorkflowRelease()
                    } catch (error: CancellationException) {
                        throw error
                    } catch (_: Exception) {
                        null
                    }
                } else {
                    null
                }
            val fallbackRelease = releasePageFallback ?: workflowFallback
            if (fallbackRelease != null) {
                val cachedLatest = cachedReleases?.let(::findLatestCanaryRelease)
                if (
                    cachedLatest != null &&
                    findLatestCanaryRelease(listOf(cachedLatest, fallbackRelease)) === cachedLatest
                ) {
                    return@runCatchingCancellable cachedReleases
                }

                val fallbackReleases = listOf(fallbackRelease)
                val fallbackJson = encodeReleasesJson(fallbackReleases)
                App.instance.dataStore.edit { settings ->
                    settings[CanaryReleasesLastCheckedAtKey] = now
                    settings.remove(CanaryReleasesEtagKey)
                    settings[CanaryReleasesJsonKey] = fallbackJson
                    settings[CanaryReleasesFingerprintKey] = getCanaryTopReleaseFingerprint(fallbackReleases)
                }
                return@runCatchingCancellable fallbackReleases
            }

            cachedReleases ?: throw IllegalStateException("No Canary update source is currently available")
        }
    }

    private suspend fun fetchLatestCanaryReleasePage(): ReleaseInfo? {
        val response: HttpResponse =
            client.get("$CanaryReleaseBaseUrl/latest") {
                headers {
                    append("User-Agent", "ArchiveTune")
                }
            }
        response.bodyAsText()
        if (response.status.value !in 200..299) return null

        val resolvedUrl = response.call.request.url.toString()
        val tagName =
            resolvedUrl
                .substringAfter("/tag/", missingDelimiterValue = "")
                .substringBefore('?')
                .trimEnd('/')
        if (!canaryTagRegex.matches(tagName)) return null

        val date = tagName.removePrefix("N")
        return ReleaseInfo(
            tagName = tagName,
            name = tagName,
            body = null,
            publishedAt =
                "${date.substring(0, 4)}-${date.substring(4, 6)}-${date.substring(6, 8)}T00:00:00Z",
            htmlUrl = resolvedUrl,
            downloadUrl = "$CanaryReleaseBaseUrl/download/$tagName/${canaryReleaseArtifactName()}",
        )
    }

    private suspend fun fetchCanaryReleasesNetwork(
        perPage: Int,
        cachedEtag: String?,
    ): ReleasesNetworkResult {
        val response: HttpResponse =
            client.get("https://api.github.com/repos/sakuraDev31/frostsoulx/releases?per_page=$perPage") {
                headers {
                    append("Accept", "application/vnd.github+json")
                    append("User-Agent", "ArchiveTune")
                    if (!cachedEtag.isNullOrBlank()) {
                        append("If-None-Match", cachedEtag)
                    }
                }
            }
        val etag = response.headers["ETag"]
        return when (response.status) {
            HttpStatusCode.NotModified -> {
                ReleasesNetworkResult(
                    status = response.status,
                    body = null,
                    etag = cachedEtag ?: etag,
                )
            }

            else -> {
                ReleasesNetworkResult(
                    status = response.status,
                    body = response.bodyAsText(),
                    etag = etag,
                )
            }
        }
    }

    private suspend fun fetchLatestWorkflowRelease(): ReleaseInfo? {
        val response: HttpResponse =
            client.get(CanaryWorkflowRunsUrl) {
                headers {
                    append("Accept", "application/vnd.github+json")
                    append("User-Agent", "ArchiveTune")
                }
            }
        val responseBody = response.bodyAsText()
        if (response.status.value !in 200..299) return null

        val workflowRun =
            JSONObject(responseBody)
                .optJSONArray("workflow_runs")
                ?.optJSONObject(0)
                ?: return null
        val publishedAt =
            workflowRun
                .optString("run_started_at")
                .ifBlank { workflowRun.optString("created_at") }
        val date = publishedAt.take(10).filter(Char::isDigit)
        if (date.length != 8) return null

        val tagName = "N$date"
        return ReleaseInfo(
            tagName = tagName,
            name = tagName,
            body = null,
            publishedAt = publishedAt,
            htmlUrl = workflowRun.optString("html_url"),
            downloadUrl = workflowArtifactDownloadUrl(),
        )
    }

    private fun getCanaryTopReleaseFingerprint(releases: List<ReleaseInfo>): String {
        val latest = findLatestCanaryRelease(releases) ?: return ""
        return listOf(
            latest.tagName,
            latest.name,
            latest.publishedAt,
            latest.body.orEmpty(),
            latest.htmlUrl,
        ).joinToString("||")
    }

    fun getLatestCanaryDownloadUrl(): String {
        if (!isUpdaterDistribution) {
            return ""
        }

        if (!canDownloadUpdatesDirectly) {
            return "$CanaryReleaseBaseUrl/latest"
        }

        latestCanaryDownloadUrl?.let { return it }
        val artifactName = canaryReleaseArtifactName()
        val tag = latestCanaryReleaseTag
        if (tag != null) {
            return "$CanaryReleaseBaseUrl/download/$tag/$artifactName"
        }
        return "$CanaryReleaseBaseUrl/latest/download/$artifactName"
    }

    suspend fun getAllReleases(
        perPage: Int = 30,
        forceRefresh: Boolean = false,
    ): Result<List<ReleaseInfo>> {
        if (!isUpdaterDistribution) {
            return Result.success(emptyList())
        }

        return runCatchingCancellable {
            val now = System.currentTimeMillis()
            val cachedJson = App.instance.dataStore.getAsync(GitHubReleasesJsonKey)
            val cachedEtag = App.instance.dataStore.getAsync(GitHubReleasesEtagKey)
            val lastCheckedAt = App.instance.dataStore.getAsync(GitHubReleasesLastCheckedAtKey, 0L)
            val cachedFingerprint = App.instance.dataStore.getAsync(GitHubReleasesFingerprintKey)

            val cachedReleases =
                cachedJson
                    ?.takeIf { it.isNotBlank() }
                    ?.let { runCatching { parseReleasesJson(it, stableReleaseArtifactName()) }.getOrNull() }

            val shouldCheckNetwork =
                forceRefresh || cachedJson.isNullOrBlank() || (now - lastCheckedAt) >= ReleaseCacheCheckIntervalMs

            if (!shouldCheckNetwork) {
                lastCheckTime = now
                return@runCatchingCancellable cachedReleases ?: emptyList()
            }

            val networkResult =
                try {
                    fetchReleasesNetwork(
                        perPage = perPage,
                        cachedEtag = cachedEtag,
                    )
                } catch (error: CancellationException) {
                    throw error
                } catch (_: Exception) {
                    null
                }

            if (networkResult == null) {
                val fallback = cachedReleases
                if (fallback != null) {
                    lastCheckTime = now
                    return@runCatchingCancellable fallback
                }
                throw IllegalStateException("Failed to fetch releases")
            }

            when {
                networkResult.status == HttpStatusCode.NotModified -> {
                    App.instance.dataStore.edit { settings ->
                        settings[GitHubReleasesLastCheckedAtKey] = now
                        networkResult.etag?.let { settings[GitHubReleasesEtagKey] = it }
                    }
                    val fallback = cachedReleases
                    if (fallback != null) {
                        lastCheckTime = now
                        return@runCatchingCancellable fallback
                    }
                    throw IllegalStateException("Release cache is empty")
                }

                networkResult.status.value in 200..299 && !networkResult.body.isNullOrBlank() -> {
                    val networkBody = networkResult.body
                    val releases = parseReleasesJson(networkBody, stableReleaseArtifactName())
                    val newFingerprint = getTopReleaseFingerprint(releases)
                    val hasPayloadChanged = cachedJson != networkBody
                    val hasTopReleaseChanged = cachedFingerprint != newFingerprint

                    App.instance.dataStore.edit { settings ->
                        settings[GitHubReleasesLastCheckedAtKey] = now
                        networkResult.etag?.let { settings[GitHubReleasesEtagKey] = it }
                        if (hasPayloadChanged || hasTopReleaseChanged || cachedJson.isNullOrBlank()) {
                            settings[GitHubReleasesJsonKey] = networkBody
                            settings[GitHubReleasesFingerprintKey] = newFingerprint
                        }
                    }
                    lastCheckTime = now
                    releases
                }

                else -> {
                    val fallback = cachedReleases
                    if (fallback != null) {
                        lastCheckTime = now
                        fallback
                    } else {
                        throw IllegalStateException("Failed to fetch releases: HTTP ${networkResult.status.value}")
                    }
                }
            }
        }
    }

    private inline fun <T> runCatchingCancellable(block: () -> T): Result<T> =
        try {
            Result.success(block())
        } catch (error: CancellationException) {
            throw error
        } catch (error: Throwable) {
            Result.failure(error)
        }
}
